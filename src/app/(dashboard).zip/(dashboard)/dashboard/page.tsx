import React from "react";

const DashboardHome = () => {
  return <div>DashboardHome</div>;
};

export default DashboardHome;
