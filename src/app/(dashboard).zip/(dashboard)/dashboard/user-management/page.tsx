import React from "react";

const AdminUserManagementPage = () => {
  return <div>AdminUserManagementPage</div>;
};

export default AdminUserManagementPage;
